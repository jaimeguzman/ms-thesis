Tarea 1 curso bigdata
Comparacion entre algoritmos de busqueda de substrings SSA, LZ-78 y Horspool

